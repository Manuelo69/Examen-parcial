package cic.ejercicio2_04;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio204Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio204Application.class, args);
	}

}
