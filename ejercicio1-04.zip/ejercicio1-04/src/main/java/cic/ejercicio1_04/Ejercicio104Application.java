package cic.ejercicio1_04;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio104Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio104Application.class, args);
	}

}
