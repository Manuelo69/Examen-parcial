package cic.ejercicio4_04;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio404Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio404Application.class, args);
	}

}
